---
Task ID: 1
Agent: Main
Task: Bổ sung Ngày phát hành vào setup thi đua + đổi FYP→IP

Work Log:
- Added issueDate field to Contest model in Prisma schema (optional DateTime)
- Updated contests API route to handle issueDate in POST (create/update)
- Added issueDate state variable in page.tsx
- Added issueDate input field in setup section (grid changed from 3→4 columns)
- Added issueDate filtering in handleSearch (exact date match on contract.issueDate)
- Added issueDate to save contest (handleSaveContest) and load contest (handleLoadContest)
- Changed all user-visible "FYP" labels to "IP" throughout the UI:
  - Header subtitle
  - Contest poster (Tổng IP, Theo HĐ/Tổng IP)
  - Condition type radio buttons (IP/HĐ, Tổng IP)
  - Bonus tier input labels (IP từ, IP đến)
  - Table headers (IP / Tổng)
  - CSV export headers
  - Copy/share text
  - Total footer (Tổng IP, Tỷ lệ thưởng / IP)
  - Source data table
  - Add contract dialog
  - Import dialog description
- Internal code variable names (fyp, minFYP, maxFYP, totalFYP, etc.) kept unchanged
- Ran prisma db push + generate to sync schema
- Server running successfully on port 3000

Stage Summary:
- Contest model now has optional issueDate field for Ngày phát hành filter
- All UI labels changed from FYP to IP per user request
- Both IP and FYP data come from the same IP column (columns[13] in CSV)

---
Task ID: 2
Agent: Main
Task: Thêm đối tượng thi đua (TVV/Nhóm) + thưởng tiền/quà tặng

Work Log:
- Added targetType field to Contest model in Prisma schema (default "tvv")
- Updated contests API route to handle targetType in POST (create/update)
- Completely rewrote page.tsx with major new features:
  1. **Đối tượng thi đua**: Radio buttons chọn TVV hoặc Nhóm
     - TVV: hiển thị từng hợp đồng cá nhân (như cũ)
     - Nhóm: gộp theo MC NHÓM, cộng IP, tên hiển thị = Trưởng nhóm
  2. **Thưởng tiền/quà**: Mỗi mức thưởng có nút chọn Tiền hoặc Quà
     - Tiền: nhập số tiền (VNĐ), hiển thị formatCurrency
     - Quà: nhập text mô tả (VD: "1 iPhone 15"), hiển thị màu hồng
  3. Updated BonusTier interface with bonusType and bonusText
  4. Added GroupData interface and groupedData computation
  5. Updated results table with different columns for TVV vs Nhóm mode
  6. Updated ContestPoster for targetType display and gift bonus
  7. Updated copy/share, CSV export for both modes
  8. Added "Chức vụ" column to source data table
  9. targetType saved/loaded with contests

Stage Summary:
- targetType: 'tvv' | 'nhom' - TVV shows individuals, Nhóm groups by MC NHÓM
- Group leader found by position containing "Trưởng nhóm"
- bonusType: 'money' | 'gift' per tier - money shows VNĐ, gift shows custom text
- Server running successfully on port 3000
