import { NextRequest, NextResponse } from 'next/server';

// GET /api/import-csv - Fetch CSV from Google Sheets URL
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const url = searchParams.get('url');

    if (!url) {
      return NextResponse.json(
        { error: 'Vui lòng cung cấp URL Google Sheets' },
        { status: 400 }
      );
    }

    const response = await fetch(url, {
      redirect: 'follow',
      headers: {
        'User-Agent': 'Mozilla/5.0',
      },
    });

    if (!response.ok) {
      return NextResponse.json(
        { error: 'Không thể tải dữ liệu từ Google Sheets' },
        { status: response.status }
      );
    }

    const csvData = await response.text();

    return NextResponse.json({ csvData });
  } catch (error) {
    console.error('Error fetching CSV:', error);
    return NextResponse.json(
      { error: 'Không thể kết nối đến Google Sheets' },
      { status: 500 }
    );
  }
}
