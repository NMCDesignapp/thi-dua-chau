'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';
import {
  Plus,
  Trash2,
  Search,
  CalendarDays,
  Trophy,
  FileText,
  TrendingUp,
  Database,
  Download,
  X,
  RefreshCw,
  Link,
  Loader2,
  Printer,
  Copy,
  Save,
  BookmarkPlus,
  Star,
  Sparkles,
  Target,
  Award,
  Users,
  Banknote,
  CalendarRange,
  Zap,
  Gift,
  UserCheck,
} from 'lucide-react';

interface Contract {
  id: string;
  contractNumber: string;
  agentCode: string;
  agentName: string;
  position: string;
  ban: string;
  nhom: string;
  maNhom: string;
  effectiveDate: string;
  issueDate: string;
  fyp: number;
  afyp: number;
}

interface BonusTier {
  id: string;
  minFYP: number;
  maxFYP: number | null;
  bonusAmount: number;
  bonusType: 'money' | 'gift';
  bonusText: string;
}

interface GroupData {
  maNhom: string;
  leaderName: string;
  leaderCode: string;
  totalFYP: number;
  contractCount: number;
  contracts: Contract[];
}

interface SavedContest {
  id: string;
  title: string;
  startDate: string;
  endDate: string;
  issueDate: string | null;
  conditionType: string;
  targetType: string;
  bonusTiers: string;
  createdAt: string;
  updatedAt: string;
}

type ConditionType = 'per_contract' | 'total_fyp';
type TargetType = 'tvv' | 'nhom';

const DEFAULT_CSV_URL = 'https://docs.google.com/spreadsheets/d/e/2PACX-1vStQqbaHb_1aP-hMzZCiVoeaSobXV5gwqw6iZBoQ0MgpsXiobO1GdCM5zoCoCxVBtxT_Nujjll_MJmC/pub?output=csv';

function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(amount);
}

function formatNumber(amount: number): string {
  return new Intl.NumberFormat('vi-VN').format(amount);
}

function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('vi-VN');
}

function formatBonus(tier: BonusTier): string {
  if (tier.bonusType === 'gift' && tier.bonusText) {
    return tier.bonusText;
  }
  return formatCurrency(tier.bonusAmount);
}

// ContestPoster Component
function ContestPoster({
  contestTitle,
  startDate,
  endDate,
  conditionType,
  targetType,
  sortedTiers,
  filteredContracts,
  groupedData,
  totalFYP,
  totalBonus,
  achievedCount,
  notAchievedCount,
  formatCurrency: fc,
  formatNumber: fn,
  formatDate: fd,
  isPreview = false,
}: {
  contestTitle: string;
  startDate: string;
  endDate: string;
  conditionType: ConditionType;
  targetType: TargetType;
  sortedTiers: BonusTier[];
  filteredContracts: Contract[];
  groupedData: GroupData[];
  totalFYP: number;
  totalBonus: number;
  achievedCount: number;
  notAchievedCount: number;
  formatCurrency: (n: number) => string;
  formatNumber: (n: number) => string;
  formatDate: (d: string) => string;
  isPreview?: boolean;
}) {
  const rowCount = targetType === 'nhom' ? groupedData.length : filteredContracts.length;
  const hasData = rowCount > 0;
  const achievementPercent = hasData ? Math.round((achievedCount / rowCount) * 100) : 0;

  const tierColors = [
    'from-amber-400 to-orange-500',
    'from-emerald-400 to-teal-500',
    'from-sky-400 to-cyan-500',
    'from-violet-400 to-purple-500',
    'from-rose-400 to-pink-500',
    'from-lime-400 to-green-500',
  ];

  return (
    <div className={`relative overflow-hidden rounded-2xl ${isPreview ? 'border-2 border-emerald-200' : ''}`}>
      <div className="absolute inset-0 bg-gradient-to-br from-emerald-700 via-teal-700 to-emerald-900" />
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(255,255,255,0.15) 0%, transparent 50%), radial-gradient(circle at 80% 20%, rgba(255,255,255,0.1) 0%, transparent 40%)' }} />
      <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-bl from-amber-400/20 to-transparent rounded-bl-full" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-tr from-teal-300/15 to-transparent rounded-tr-full" />

      <div className="relative z-10 p-5 sm:p-6">
        <div className="flex items-start gap-3 mb-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-lg flex-shrink-0">
            <Trophy className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-wide leading-tight break-words">
              {contestTitle || 'CHƯƠNG TRÌNH THI ĐUA'}
            </h2>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <div className="flex items-center gap-1 text-emerald-200 text-xs">
                <CalendarRange className="w-3.5 h-3.5" />
                <span>{startDate ? fd(startDate) : '...'} — {endDate ? fd(endDate) : '...'}</span>
              </div>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/15 text-emerald-100 backdrop-blur-sm">
                <Target className="w-3 h-3" />
                {conditionType === 'per_contract' ? 'Theo HĐ' : 'Tổng IP'}
              </span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/15 text-sky-100 backdrop-blur-sm">
                {targetType === 'tvv' ? <><Users className="w-3 h-3" /> TVV</> : <><UserCheck className="w-3 h-3" /> Nhóm</>}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg bg-amber-400/20 backdrop-blur-sm flex-shrink-0">
            <Star className="w-4 h-4 text-amber-300" />
            <span className="text-xs font-bold text-amber-200">THI ĐUA</span>
          </div>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-1 mb-4 scrollbar-none">
          {sortedTiers.map((tier, i) => (
            <div
              key={tier.id}
              className={`flex-shrink-0 rounded-xl px-3 py-2 bg-gradient-to-br ${tierColors[i % tierColors.length]} text-white min-w-[120px] shadow-md`}
            >
              <div className="flex items-center gap-1 mb-0.5">
                {tier.bonusType === 'gift' ? <Gift className="w-3 h-3 opacity-80" /> : <Sparkles className="w-3 h-3 opacity-80" />}
                <span className="text-[10px] font-bold uppercase opacity-90">Mức {i + 1}</span>
              </div>
              <div className="text-[11px] font-semibold leading-tight">
                {fc(tier.minFYP)}{tier.maxFYP ? ` - ${fc(tier.maxFYP)}` : ' ↑'}
              </div>
              <div className="text-sm font-extrabold mt-0.5 truncate" title={formatBonus(tier)}>
                {formatBonus(tier)}
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 mb-1">
              <FileText className="w-3.5 h-3.5 text-emerald-300" />
              <span className="text-[10px] text-emerald-300 uppercase font-medium">{targetType === 'nhom' ? 'Nhóm' : 'Tổng HĐ'}</span>
            </div>
            <p className="text-2xl font-extrabold text-white">{hasData ? rowCount : '—'}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Banknote className="w-3.5 h-3.5 text-amber-300" />
              <span className="text-[10px] text-amber-300 uppercase font-medium">Tổng IP</span>
            </div>
            <p className="text-base font-extrabold text-amber-200">{hasData ? fc(totalFYP) : '—'}</p>
          </div>
          <div className="bg-white/10 backdrop-blur-sm rounded-xl p-3 text-center border border-white/10">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Users className="w-3.5 h-3.5 text-sky-300" />
              <span className="text-[10px] text-sky-300 uppercase font-medium">Đạt / Chưa đạt</span>
            </div>
            <p className="text-2xl font-extrabold">
              {hasData ? (
                <>
                  <span className="text-emerald-300">{achievedCount}</span>
                  <span className="text-white/40 mx-0.5">/</span>
                  <span className="text-red-300">{notAchievedCount}</span>
                </>
              ) : (
                <span className="text-white/40">—</span>
              )}
            </p>
          </div>
          <div className="bg-gradient-to-br from-amber-500/30 to-orange-500/20 backdrop-blur-sm rounded-xl p-3 text-center border border-amber-400/30">
            <div className="flex items-center justify-center gap-1 mb-1">
              <Award className="w-3.5 h-3.5 text-amber-200" />
              <span className="text-[10px] text-amber-200 uppercase font-medium">Tổng Thưởng</span>
            </div>
            <p className="text-base font-extrabold text-amber-100">{hasData ? fc(totalBonus) : '—'}</p>
          </div>
        </div>

        {hasData && (
          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="text-emerald-200 font-medium">Tỷ lệ đạt thưởng</span>
              <span className="text-white font-bold">{achievementPercent}%</span>
            </div>
            <div className="relative h-3 bg-white/10 rounded-full overflow-hidden">
              <div
                className="absolute inset-y-0 left-0 bg-gradient-to-r from-emerald-400 to-amber-400 rounded-full transition-all duration-700"
                style={{ width: `${achievementPercent}%` }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-[9px] font-bold text-white drop-shadow-sm">
                  {achievedCount}/{rowCount} {targetType === 'nhom' ? 'nhóm' : 'HĐ'}
                </span>
              </div>
            </div>
          </div>
        )}

        {!hasData && isPreview && (
          <div className="text-center py-2">
            <p className="text-emerald-200/60 text-xs italic">Nhấn &ldquo;Tính kết quả thi đua&rdquo; để xem dữ liệu</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function Home() {
  // Filter state
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [issueDate, setIssueDate] = useState('');
  const [contestTitle, setContestTitle] = useState('CHƯƠNG TRÌNH THI ĐUA');

  // Condition type
  const [conditionType, setConditionType] = useState<ConditionType>('per_contract');

  // Target type: TVV or Nhóm
  const [targetType, setTargetType] = useState<TargetType>('tvv');

  // Bonus tiers
  const [bonusTiers, setBonusTiers] = useState<BonusTier[]>([
    { id: crypto.randomUUID(), minFYP: 0, maxFYP: 20000000, bonusAmount: 500000, bonusType: 'money', bonusText: '' },
    { id: crypto.randomUUID(), minFYP: 20000000, maxFYP: 50000000, bonusAmount: 1500000, bonusType: 'money', bonusText: '' },
    { id: crypto.randomUUID(), minFYP: 50000000, maxFYP: 100000000, bonusAmount: 3000000, bonusType: 'money', bonusText: '' },
    { id: crypto.randomUUID(), minFYP: 100000000, maxFYP: null, bonusAmount: 5000000, bonusType: 'money', bonusText: '' },
  ]);

  // Contracts
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [filteredContracts, setFilteredContracts] = useState<Contract[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // Import state
  const [isImporting, setIsImporting] = useState(false);
  const [csvUrl, setCsvUrl] = useState(DEFAULT_CSV_URL);
  const [isImportDialogOpen, setIsImportDialogOpen] = useState(false);

  // Add contract dialog
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [newContract, setNewContract] = useState({
    contractNumber: '', agentCode: '', agentName: '', position: '', ban: '', nhom: '', maNhom: '',
    effectiveDate: '', issueDate: '', fyp: '', afyp: '',
  });

  // Saved contests state
  const [savedContests, setSavedContests] = useState<SavedContest[]>([]);
  const [selectedContestId, setSelectedContestId] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);

  // Print ref
  const printRef = useRef<HTMLDivElement>(null);

  // Fetch all contracts
  const fetchContracts = useCallback(async () => {
    setIsLoading(true);
    try {
      const res = await fetch('/api/contracts');
      if (res.ok) {
        const data = await res.json();
        setContracts(data);
      }
    } catch {
      toast({ title: 'Lỗi', description: 'Không thể tải danh sách hợp đồng', variant: 'destructive' });
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchContracts();
  }, [fetchContracts]);

  // Fetch saved contests
  const fetchSavedContests = useCallback(async () => {
    try {
      const res = await fetch('/api/contests');
      if (res.ok) {
        const data = await res.json();
        setSavedContests(data);
      }
    } catch {
      // silent fail
    }
  }, []);

  useEffect(() => {
    fetchSavedContests();
  }, [fetchSavedContests]);

  // Filter contracts
  const handleSearch = useCallback(() => {
    if (!startDate && !endDate) {
      setFilteredContracts([]);
      toast({ title: 'Thông báo', description: 'Vui lòng nhập ít nhất Ngày hiệu lực từ hoặc đến' });
      return;
    }
    let results = [...contracts];
    if (startDate) {
      const start = new Date(startDate);
      results = results.filter((c) => new Date(c.effectiveDate) >= start);
    }
    if (endDate) {
      const end = new Date(endDate);
      end.setHours(23, 59, 59, 999);
      results = results.filter((c) => new Date(c.effectiveDate) <= end);
    }
    if (issueDate) {
      const issue = new Date(issueDate);
      results = results.filter((c) => {
        const cIssue = new Date(c.issueDate);
        return cIssue.getFullYear() === issue.getFullYear() && cIssue.getMonth() === issue.getMonth() && cIssue.getDate() === issue.getDate();
      });
    }
    results.sort((a, b) => new Date(a.effectiveDate).getTime() - new Date(b.effectiveDate).getTime());
    setFilteredContracts(results);
    if (results.length === 0) {
      toast({ title: 'Thông báo', description: 'Không tìm thấy hợp đồng nào phù hợp' });
    } else {
      toast({ title: 'Thành công', description: `Tìm thấy ${results.length} hợp đồng` });
    }
  }, [startDate, endDate, issueDate, contracts]);

  // Ref for handleSearch
  const handleSearchRef = useRef(handleSearch);
  handleSearchRef.current = handleSearch;

  // Calculate bonus for a given FYP
  const calculateBonus = useCallback(
    (fyp: number): { tier: BonusTier | null; tierIndex: number } => {
      const sortedTiers = [...bonusTiers].sort((a, b) => a.minFYP - b.minFYP);
      for (let i = sortedTiers.length - 1; i >= 0; i--) {
        const tier = sortedTiers[i];
        if (fyp >= tier.minFYP) {
          return { tier, tierIndex: i };
        }
      }
      return { tier: null, tierIndex: -1 };
    },
    [bonusTiers]
  );

  // Get bonus display for a tier
  const getBonusDisplay = useCallback((fyp: number): string => {
    const { tier } = calculateBonus(fyp);
    if (!tier) return '—';
    return formatBonus(tier);
  }, [calculateBonus]);

  // Get bonus amount (monetary) for a tier
  const getBonusAmount = useCallback((fyp: number): number => {
    const { tier } = calculateBonus(fyp);
    return tier ? tier.bonusAmount : 0;
  }, [calculateBonus]);

  // Get remaining FYP to next tier
  const getRemainingToNextTier = useCallback(
    (fyp: number): number | null => {
      const sortedTiers = [...bonusTiers].sort((a, b) => a.minFYP - b.minFYP);
      for (const tier of sortedTiers) {
        if (tier.minFYP > fyp) {
          return tier.minFYP - fyp;
        }
      }
      return null;
    },
    [bonusTiers]
  );

  // Group data computation for Nhóm mode
  const groupedData: GroupData[] = (() => {
    if (targetType !== 'nhom') return [];
    const map = new Map<string, GroupData>();
    for (const c of filteredContracts) {
      const key = c.maNhom;
      if (!map.has(key)) {
        map.set(key, { maNhom: key, leaderName: '', leaderCode: '', totalFYP: 0, contractCount: 0, contracts: [] });
      }
      const g = map.get(key)!;
      g.totalFYP += c.fyp;
      g.contractCount += 1;
      g.contracts.push(c);
      // Find leader: position contains "Trưởng nhóm"
      if (c.position && c.position.toLowerCase().includes('trưởng nhóm')) {
        g.leaderName = c.agentName;
        g.leaderCode = c.agentCode;
      }
    }
    return Array.from(map.values());
  })();

  // Total FYP bonus calculation
  const getTotalFYPBonus = useCallback((): { totalFYP: number; bonus: number; tier: BonusTier | null; remaining: number | null } => {
    const totalFYP = filteredContracts.reduce((sum, c) => sum + c.fyp, 0);
    const { tier } = calculateBonus(totalFYP);
    const remaining = getRemainingToNextTier(totalFYP);
    return { totalFYP, bonus: tier?.bonusAmount || 0, tier, remaining };
  }, [filteredContracts, calculateBonus, getRemainingToNextTier]);

  // Add bonus tier
  const addBonusTier = () => {
    setBonusTiers([...bonusTiers, { id: crypto.randomUUID(), minFYP: 0, maxFYP: null, bonusAmount: 0, bonusType: 'money', bonusText: '' }]);
  };

  // Remove bonus tier
  const removeBonusTier = (id: string) => {
    if (bonusTiers.length <= 1) {
      toast({ title: 'Thông báo', description: 'Phải có ít nhất một mức thưởng' });
      return;
    }
    setBonusTiers(bonusTiers.filter((t) => t.id !== id));
  };

  // Update bonus tier
  const updateBonusTier = (id: string, field: keyof BonusTier, value: string | number | null) => {
    setBonusTiers(bonusTiers.map((t) => (t.id === id ? { ...t, [field]: value } : t)));
  };

  // Save contest
  const handleSaveContest = async () => {
    if (!contestTitle) {
      toast({ title: 'Lỗi', description: 'Nhập tên chương trình' });
      return;
    }
    setIsSaving(true);
    try {
      const res = await fetch('/api/contests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: contestTitle,
          startDate,
          endDate,
          issueDate: issueDate || undefined,
          conditionType,
          targetType,
          bonusTiers: JSON.stringify(bonusTiers),
        }),
      });
      if (res.ok) {
        const data = await res.json();
        toast({ title: 'Thành công', description: data.message });
        fetchSavedContests();
      } else {
        toast({ title: 'Lỗi', description: 'Không thể lưu', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Lỗi', description: 'Không thể lưu', variant: 'destructive' });
    } finally {
      setIsSaving(false);
    }
  };

  // Load contest
  const handleLoadContest = (contestId: string) => {
    setSelectedContestId(contestId);
    const contest = savedContests.find(c => c.id === contestId);
    if (!contest) return;
    setContestTitle(contest.title);
    const sd = new Date(contest.startDate);
    setStartDate(sd.toISOString().slice(0, 10));
    const ed = new Date(contest.endDate);
    setEndDate(ed.toISOString().slice(0, 10));
    setConditionType(contest.conditionType as ConditionType);
    setTargetType((contest.targetType || 'tvv') as TargetType);
    if (contest.issueDate) {
      const id2 = new Date(contest.issueDate);
      setIssueDate(id2.toISOString().slice(0, 10));
    } else {
      setIssueDate('');
    }
    try {
      const tiers = JSON.parse(contest.bonusTiers);
      if (Array.isArray(tiers)) setBonusTiers(tiers);
    } catch {
      // ignore parse error
    }
    setTimeout(() => handleSearchRef.current(), 100);
  };

  // Delete contest
  const handleDeleteContest = async (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    try {
      const res = await fetch(`/api/contests?id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        toast({ title: 'Thành công', description: 'Đã xóa chương trình' });
        fetchSavedContests();
        if (selectedContestId === id) setSelectedContestId('');
      }
    } catch {
      toast({ title: 'Lỗi', description: 'Không thể xóa', variant: 'destructive' });
    }
  };

  // Import from Google Sheets
  const handleImportFromUrl = async () => {
    setIsImporting(true);
    try {
      const fetchRes = await fetch(`/api/import-csv?url=${encodeURIComponent(csvUrl)}`);
      if (!fetchRes.ok) { const errData = await fetchRes.json(); throw new Error(errData.error || 'Không thể tải CSV'); }
      const { csvData } = await fetchRes.json();
      const importRes = await fetch('/api/seed', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ csvData }) });
      if (!importRes.ok) { const errData = await importRes.json(); throw new Error(errData.error || 'Không thể nhập dữ liệu'); }
      const data = await importRes.json();
      toast({ title: 'Thành công', description: data.message });
      setIsImportDialogOpen(false);
      fetchContracts();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Lỗi không xác định';
      toast({ title: 'Lỗi nhập dữ liệu', description: msg, variant: 'destructive' });
    } finally {
      setIsImporting(false);
    }
  };

  // Create contract manually
  const handleCreateContract = async () => {
    try {
      const res = await fetch('/api/contracts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...newContract, fyp: parseFloat(newContract.fyp) || 0, afyp: parseFloat(newContract.afyp) || 0, effectiveDate: newContract.effectiveDate, issueDate: newContract.issueDate || newContract.effectiveDate }),
      });
      if (res.ok) {
        toast({ title: 'Thành công', description: 'Đã tạo hợp đồng mới' });
        setIsAddDialogOpen(false);
        setNewContract({ contractNumber: '', agentCode: '', agentName: '', position: '', ban: '', nhom: '', maNhom: '', effectiveDate: '', issueDate: '', fyp: '', afyp: '' });
        fetchContracts();
      } else {
        const data = await res.json();
        toast({ title: 'Lỗi', description: data.error || 'Không thể tạo hợp đồng', variant: 'destructive' });
      }
    } catch {
      toast({ title: 'Lỗi', description: 'Không thể kết nối đến máy chủ', variant: 'destructive' });
    }
  };

  // Delete contract
  const handleDeleteContract = async (id: string) => {
    try {
      const res = await fetch(`/api/contracts?id=${id}`, { method: 'DELETE' });
      if (res.ok) { toast({ title: 'Thành công', description: 'Đã xóa hợp đồng' }); fetchContracts(); setFilteredContracts((prev) => prev.filter((c) => c.id !== id)); }
    } catch {
      toast({ title: 'Lỗi', description: 'Không thể xóa hợp đồng', variant: 'destructive' });
    }
  };

  // Print results
  const handlePrint = () => {
    if (!printRef.current) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    const styles = `
      <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', Arial, sans-serif; padding: 20px; background: white; color: #1a1a1a; }
        .header { text-align: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 3px solid #059669; }
        .header h1 { font-size: 18px; font-weight: 800; color: #059669; letter-spacing: 1px; margin-bottom: 4px; }
        .header .subtitle { font-size: 12px; color: #666; }
        table { width: 100%; border-collapse: collapse; font-size: 11px; }
        th { background: #064e3b; color: white; padding: 8px 6px; text-align: left; font-weight: 600; font-size: 10px; white-space: normal; }
        td { padding: 7px 6px; border-bottom: 1px solid #e5e7eb; white-space: nowrap; }
        tr:nth-child(even) { background: #f9fafb; }
        .total-row { background: #1f2937 !important; color: white; font-weight: 700; }
        .total-row td { color: white; border-bottom: none; }
        @media print { body { padding: 10px; } }
      </style>
    `;
    const html = printRef.current.innerHTML;
    printWindow.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8">${styles}</head><body>${html}</body></html>`);
    printWindow.document.close();
    setTimeout(() => { printWindow.print(); }, 500);
  };

  // Copy as text for sharing
  const handleCopyText = () => {
    if (filteredContracts.length === 0) return;
    const sortedTiers = [...bonusTiers].sort((a, b) => a.minFYP - b.minFYP);
    let text = `🏆 ${contestTitle}\n`;
    text += `📅 Từ ${startDate ? formatDate(startDate) : '...'} đến ${endDate ? formatDate(endDate) : '...'}\n`;
    text += `🎯 Đối tượng: ${targetType === 'tvv' ? 'TVV' : 'Nhóm'}\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    text += `📊 Mức thưởng:\n`;
    sortedTiers.forEach((t, i) => {
      text += `  Mức ${i + 1}: ${formatCurrency(t.minFYP)}${t.maxFYP ? ` - ${formatCurrency(t.maxFYP)}` : ' ↑'} → ${formatBonus(t)}\n`;
    });
    text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;

    if (conditionType === 'total_fyp') {
      const { totalFYP, bonus, remaining } = getTotalFYPBonus();
      text += `\n📊 TỔNG IP: ${formatCurrency(totalFYP)}\n`;
      text += `🎁 Thưởng: ${formatCurrency(bonus)}\n`;
      if (remaining !== null) text += `⚡ Còn thiếu: ${formatCurrency(remaining)} để đạt mức tiếp\n`;
      text += `\n`;
    }

    if (targetType === 'nhom') {
      // Group mode
      const sortedGroups = [...groupedData]
        .map((g) => {
          const { tier } = calculateBonus(g.totalFYP);
          const remaining = getRemainingToNextTier(g.totalFYP);
          return { group: g, tier, remaining };
        })
        .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.group.totalFYP - a.group.totalFYP);

      sortedGroups.forEach(({ group: g, tier, remaining }, idx) => {
        const achieved = tier !== null;
        const displayName = g.leaderName || g.maNhom;
        text += `${idx + 1}. ${g.maNhom} | ${displayName} | ${g.contractCount} HĐ | IP: ${formatNumber(g.totalFYP)} | `;
        if (achieved && tier) {
          text += `Thưởng: ${formatBonus(tier)}`;
        } else {
          text += `Thưởng: —`;
          if (remaining !== null) text += ` | _Còn thiếu ${formatNumber(remaining)}_`;
        }
        text += `\n`;
      });

      const totalGroupIP = groupedData.reduce((s, g) => s + g.totalFYP, 0);
      const totalGroupBonus = groupedData.reduce((s, g) => s + getBonusAmount(g.totalFYP), 0);
      const groupAchieved = groupedData.filter((g) => getBonusAmount(g.totalFYP) > 0).length;
      text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      text += `📈 TỔNG: ${groupedData.length} nhóm | IP: ${formatCurrency(totalGroupIP)} | Thưởng: ${formatCurrency(totalGroupBonus)}\n`;
      text += `✅ Đạt: ${groupAchieved}/${groupedData.length} | ❌ Chưa đạt: ${groupedData.length - groupAchieved}/${groupedData.length}`;
    } else {
      // TVV mode - per contract
      const sorted = [...filteredContracts]
        .map((c) => {
          const { tier } = conditionType === 'per_contract' ? calculateBonus(c.fyp) : { tier: null as BonusTier | null };
          const remaining = conditionType === 'per_contract' ? getRemainingToNextTier(c.fyp) : null;
          return { contract: c, tier, remaining };
        })
        .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.contract.fyp - a.contract.fyp);

      sorted.forEach(({ contract: c, tier, remaining }, idx) => {
        const achieved = tier !== null;
        text += `${idx + 1}. ${c.maNhom} | ${c.agentCode} | ${c.agentName} | ${formatDate(c.effectiveDate)} | IP: ${formatNumber(c.fyp)} | `;
        if (achieved && tier) {
          text += `Thưởng: ${formatBonus(tier)}`;
        } else {
          text += `Thưởng: —`;
          if (remaining !== null) text += ` | _Còn thiếu ${formatNumber(remaining)}_`;
        }
        text += `\n`;
      });

      const totalFYP = filteredContracts.reduce((s, c) => s + c.fyp, 0);
      const totalBonus = filteredContracts.reduce((s, c) => s + getBonusAmount(c.fyp), 0);
      const ac = filteredContracts.filter((c) => getBonusAmount(c.fyp) > 0).length;
      text += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
      text += `📈 TỔNG: ${filteredContracts.length} HĐ | IP: ${formatCurrency(totalFYP)} | Thưởng: ${formatCurrency(totalBonus)}\n`;
      text += `✅ Đạt: ${ac}/${filteredContracts.length} | ❌ Chưa đạt: ${filteredContracts.length - ac}/${filteredContracts.length}`;
    }

    navigator.clipboard.writeText(text).then(() => {
      toast({ title: 'Đã sao chép!', description: 'Dán vào Zalo/Telegram để chia sẻ' });
    }).catch(() => {
      toast({ title: 'Lỗi', description: 'Không thể sao chép', variant: 'destructive' });
    });
  };

  // Export to CSV
  const handleExport = () => {
    if (filteredContracts.length === 0) { toast({ title: 'Thông báo', description: 'Không có dữ liệu để xuất' }); return; }

    if (targetType === 'nhom') {
      const headers = ['STT', 'Mã nhóm', 'Trưởng nhóm', 'Số HĐ', 'Tổng IP', 'Thưởng', 'Ghi chú'];
      const sorted = [...groupedData]
        .map((g) => {
          const { tier } = calculateBonus(g.totalFYP);
          const remaining = getRemainingToNextTier(g.totalFYP);
          return { group: g, tier, remaining };
        })
        .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.group.totalFYP - a.group.totalFYP);
      const rows = sorted.map(({ group: g, tier, remaining }, idx) => {
        const achieved = tier !== null;
        const bonusText = achieved && tier ? formatBonus(tier) : '';
        const note = achieved ? '' : remaining !== null ? `Còn thiếu ${formatNumber(remaining)}` : 'Chưa đạt mức';
        return [idx + 1, g.maNhom, g.leaderName || g.maNhom, g.contractCount, g.totalFYP, bonusText, note];
      });
      const csvContent = [headers.join(','), ...rows.map((r) => r.map((v) => `"${v}"`).join(','))].join('\n');
      const BOM = '\uFEFF';
      const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `ket_qua_thi_dua_nhom_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(link.href);
    } else {
      const headers = ['STT', 'Nhóm', 'Mã số', 'Họ tên', 'Ngày hiệu lực', 'IP / Tổng', 'Thưởng', 'Ghi chú'];
      const sorted = [...filteredContracts]
        .map((c) => {
          const { tier } = conditionType === 'per_contract' ? calculateBonus(c.fyp) : { tier: null as BonusTier | null };
          const remaining = conditionType === 'per_contract' ? getRemainingToNextTier(c.fyp) : null;
          return { contract: c, tier, remaining };
        })
        .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.contract.fyp - a.contract.fyp);
      const rows = sorted.map(({ contract: c, tier, remaining }, idx) => {
        const achieved = tier !== null;
        const bonusText = achieved && tier ? formatBonus(tier) : '';
        const note = achieved ? '' : remaining !== null ? `Còn thiếu ${formatNumber(remaining)}` : 'Chưa đạt mức';
        return [idx + 1, c.maNhom, c.agentCode, c.agentName, formatDate(c.effectiveDate), c.fyp, bonusText, note];
      });
      if (conditionType === 'total_fyp') {
        const { totalFYP, bonus } = getTotalFYPBonus();
        rows.push(['', '', '', 'TỔNG CỘNG', '', totalFYP, bonus, 'Thưởng theo tổng IP']);
      } else {
        const totalFYP = filteredContracts.reduce((s, c) => s + c.fyp, 0);
        const totalBonus = filteredContracts.reduce((s, c) => s + getBonusAmount(c.fyp), 0);
        rows.push(['', '', '', 'TỔNG CỘNG', '', totalFYP, totalBonus, '']);
      }
      const csvContent = [headers.join(','), ...rows.map((r) => r.map((v) => `"${v}"`).join(','))].join('\n');
      const BOM = '\uFEFF';
      const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `ket_qua_thi_dua_${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(link.href);
    }
    toast({ title: 'Thành công', description: 'Đã xuất file CSV' });
  };

  // Computed values
  const totalFYP = filteredContracts.reduce((sum, c) => sum + c.fyp, 0);

  // TVV mode stats
  const tvvAchievedCount = filteredContracts.filter((c) => calculateBonus(c.fyp).tier !== null).length;
  const tvvNotAchievedCount = filteredContracts.length - tvvAchievedCount;
  const tvvTotalBonus = filteredContracts.reduce((sum, c) => sum + getBonusAmount(c.fyp), 0);

  // Nhóm mode stats
  const nhomAchievedCount = groupedData.filter((g) => calculateBonus(g.totalFYP).tier !== null).length;
  const nhomNotAchievedCount = groupedData.length - nhomAchievedCount;
  const nhomTotalFYP = groupedData.reduce((s, g) => s + g.totalFYP, 0);
  const nhomTotalBonus = groupedData.reduce((s, g) => s + getBonusAmount(g.totalFYP), 0);

  // Select based on mode
  const achievedCount = targetType === 'nhom' ? nhomAchievedCount : tvvAchievedCount;
  const notAchievedCount = targetType === 'nhom' ? nhomNotAchievedCount : tvvNotAchievedCount;
  const totalBonusDisplay = targetType === 'nhom' ? nhomTotalBonus : (conditionType === 'total_fyp' ? getTotalFYPBonus().bonus : tvvTotalBonus);
  const displayTotalFYP = targetType === 'nhom' ? nhomTotalFYP : totalFYP;

  const { totalFYP: totalFYPValue, bonus: totalFYPBonusAmount, tier: matchedTotalTier, remaining: totalRemaining } = getTotalFYPBonus();
  const sortedTiers = [...bonusTiers].sort((a, b) => a.minFYP - b.minFYP);

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
              <Trophy className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">Tính Thưởng Thi Đua</h1>
              <p className="text-xs text-gray-500">Hệ thống quản lý & tính thưởng IP</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Dialog open={isImportDialogOpen} onOpenChange={setIsImportDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="border-emerald-300 text-emerald-700 hover:bg-emerald-50">
                  <Link className="w-4 h-4 mr-1" /> Nhập Google Sheets
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>Nhập dữ liệu từ Google Sheets</DialogTitle>
                  <DialogDescription>Dán liên kết CSV để nhập dữ liệu hợp đồng</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label>Liên kết CSV</Label>
                    <Input value={csvUrl} onChange={(e) => setCsvUrl(e.target.value)} className="font-mono text-xs" />
                  </div>
                  <div className="rounded-lg bg-amber-50 border border-amber-200 p-3 text-xs text-amber-800">
                    <p className="font-medium mb-1">Cột dữ liệu sử dụng:</p>
                    <ul className="space-y-0.5 ml-3 list-disc">
                      <li><b>Ngày hiệu lực</b> → Ngày bắt đầu thi đua</li>
                      <li><b>PĐT + 10% ĐT</b> → IP</li>
                      <li><b>AFYP</b> → AFYP</li>
                    </ul>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsImportDialogOpen(false)}>Hủy</Button>
                  <Button onClick={handleImportFromUrl} disabled={isImporting} className="bg-emerald-600 hover:bg-emerald-700">
                    {isImporting ? <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Đang nhập...</> : <><RefreshCw className="w-4 h-4 mr-1" /> Nhập dữ liệu</>}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="w-4 h-4 mr-1" /> Thêm HĐ
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Thêm hợp đồng mới</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Số HĐ</Label><Input placeholder="10000017624818" value={newContract.contractNumber} onChange={(e) => setNewContract({ ...newContract, contractNumber: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Mã đại lý</Label><Input placeholder="D104142435" value={newContract.agentCode} onChange={(e) => setNewContract({ ...newContract, agentCode: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Tên TVV</Label><Input placeholder="Nguyễn Văn A" value={newContract.agentName} onChange={(e) => setNewContract({ ...newContract, agentName: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Chức vụ</Label><Select value={newContract.position} onValueChange={(v) => setNewContract({ ...newContract, position: v })}><SelectTrigger><SelectValue placeholder="Chọn" /></SelectTrigger><SelectContent><SelectItem value="Tư vấn tài chính">TVV</SelectItem><SelectItem value="Trưởng nhóm">Trưởng nhóm</SelectItem><SelectItem value="Tiền trưởng nhóm">Tiền trưởng nhóm</SelectItem></SelectContent></Select></div>
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2"><Label>Ban</Label><Input value={newContract.ban} onChange={(e) => setNewContract({ ...newContract, ban: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Nhóm</Label><Input value={newContract.nhom} onChange={(e) => setNewContract({ ...newContract, nhom: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Mã nhóm</Label><Input value={newContract.maNhom} onChange={(e) => setNewContract({ ...newContract, maNhom: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>Ngày hiệu lực</Label><Input type="date" value={newContract.effectiveDate} onChange={(e) => setNewContract({ ...newContract, effectiveDate: e.target.value })} /></div>
                    <div className="space-y-2"><Label>Ngày phát hành</Label><Input type="date" value={newContract.issueDate} onChange={(e) => setNewContract({ ...newContract, issueDate: e.target.value })} /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>IP (VNĐ)</Label><Input type="number" value={newContract.fyp} onChange={(e) => setNewContract({ ...newContract, fyp: e.target.value })} /></div>
                    <div className="space-y-2"><Label>AFYP (VNĐ)</Label><Input type="number" value={newContract.afyp} onChange={(e) => setNewContract({ ...newContract, afyp: e.target.value })} /></div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Hủy</Button>
                  <Button onClick={handleCreateContract} className="bg-emerald-600 hover:bg-emerald-700">Tạo hợp đồng</Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Search & Config */}
        <Card className="border-emerald-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-emerald-600" />
                <CardTitle className="text-lg">Thiết lập chương trình thi đua</CardTitle>
              </div>
              <div className="flex items-center gap-2">
                <Select value={selectedContestId} onValueChange={handleLoadContest}>
                  <SelectTrigger className="w-[220px] h-9 text-xs">
                    <BookmarkPlus className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                    <SelectValue placeholder="Chương trình đã lưu..." />
                  </SelectTrigger>
                  <SelectContent>
                    {savedContests.length === 0 ? (
                      <SelectItem value="_none" disabled>Chưa có chương trình nào</SelectItem>
                    ) : (
                      savedContests.map((sc) => (
                        <SelectItem key={sc.id} value={sc.id} className="flex items-center justify-between">
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <span className="truncate">{sc.title}</span>
                            <Button variant="ghost" size="sm" className="h-5 w-5 p-0 text-red-400 hover:text-red-600 flex-shrink-0" onClick={(e) => handleDeleteContest(sc.id, e)}>
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </SelectItem>
                      ))
                    )}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={handleSaveContest} disabled={isSaving} className="border-amber-300 text-amber-700 hover:bg-amber-50">
                  {isSaving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
                  Lưu chương trình
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label>Tên chương trình thi đua</Label>
                <Input value={contestTitle} onChange={(e) => setContestTitle(e.target.value)} className="font-semibold border-emerald-200" />
              </div>
              <div className="space-y-2">
                <Label>Ngày hiệu lực từ</Label>
                <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="border-emerald-200" />
              </div>
              <div className="space-y-2">
                <Label>Ngày hiệu lực đến</Label>
                <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="border-emerald-200" />
              </div>
              <div className="space-y-2">
                <Label>Ngày phát hành</Label>
                <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} className="border-emerald-200" />
              </div>
            </div>

            <Separator className="my-4" />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Target Type */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Đối tượng thi đua</Label>
                <RadioGroup value={targetType} onValueChange={(v) => setTargetType(v as TargetType)} className="space-y-2">
                  <div className="flex items-center space-x-2 rounded-lg border p-3 cursor-pointer hover:bg-emerald-50 transition-colors">
                    <RadioGroupItem value="tvv" id="tvv" />
                    <Label htmlFor="tvv" className="cursor-pointer flex-1">
                      <div className="font-medium flex items-center gap-1.5"><Users className="w-4 h-4 text-emerald-600" /> TVV (từng cá nhân)</div>
                      <div className="text-xs text-muted-foreground">Thưởng tính cho từng tư vấn viên</div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border p-3 cursor-pointer hover:bg-emerald-50 transition-colors">
                    <RadioGroupItem value="nhom" id="nhom" />
                    <Label htmlFor="nhom" className="cursor-pointer flex-1">
                      <div className="font-medium flex items-center gap-1.5"><UserCheck className="w-4 h-4 text-sky-600" /> Theo nhóm (MC NHÓM)</div>
                      <div className="text-xs text-muted-foreground">Cộng IP theo nhóm, tên Trưởng nhóm hiển thị</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Condition Type */}
              <div className="space-y-3">
                <Label className="text-sm font-medium">Điều kiện thi đua</Label>
                <RadioGroup value={conditionType} onValueChange={(v) => setConditionType(v as ConditionType)} className="space-y-2">
                  <div className="flex items-center space-x-2 rounded-lg border p-3 cursor-pointer hover:bg-amber-50 transition-colors">
                    <RadioGroupItem value="per_contract" id="per_contract" />
                    <Label htmlFor="per_contract" className="cursor-pointer flex-1">
                      <div className="font-medium">Theo hợp đồng (IP/HĐ)</div>
                      <div className="text-xs text-muted-foreground">Thưởng tính trên IP từng HĐ/Nhóm</div>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2 rounded-lg border p-3 cursor-pointer hover:bg-amber-50 transition-colors">
                    <RadioGroupItem value="total_fyp" id="total_fyp" />
                    <Label htmlFor="total_fyp" className="cursor-pointer flex-1">
                      <div className="font-medium">Tổng IP</div>
                      <div className="text-xs text-muted-foreground">Thưởng tính trên tổng IP tất cả</div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Bonus Tiers */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label className="text-sm font-medium">Bảng mức thưởng</Label>
                  <Button variant="ghost" size="sm" onClick={addBonusTier} className="text-amber-600 hover:text-amber-700">
                    <Plus className="w-4 h-4 mr-1" /> Thêm mức
                  </Button>
                </div>
                <div className="space-y-2 max-h-52 overflow-y-auto pr-1">
                  {bonusTiers.map((tier, index) => (
                    <div key={tier.id} className="p-2 rounded-lg bg-amber-50/50 border border-amber-100">
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-xs font-bold text-amber-700">Mức {index + 1}</span>
                        {/* Bonus type toggle */}
                        <div className="flex items-center gap-1 ml-auto">
                          <Button
                            variant={tier.bonusType === 'money' ? 'default' : 'outline'}
                            size="sm"
                            className={`h-6 px-2 text-[10px] ${tier.bonusType === 'money' ? 'bg-emerald-600 hover:bg-emerald-700' : ''}`}
                            onClick={() => updateBonusTier(tier.id, 'bonusType', 'money')}
                          >
                            <Banknote className="w-3 h-3 mr-0.5" /> Tiền
                          </Button>
                          <Button
                            variant={tier.bonusType === 'gift' ? 'default' : 'outline'}
                            size="sm"
                            className={`h-6 px-2 text-[10px] ${tier.bonusType === 'gift' ? 'bg-pink-600 hover:bg-pink-700' : ''}`}
                            onClick={() => updateBonusTier(tier.id, 'bonusType', 'gift')}
                          >
                            <Gift className="w-3 h-3 mr-0.5" /> Quà
                          </Button>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => removeBonusTier(tier.id)} className="h-6 w-6 p-0 text-red-400 hover:text-red-600"><Trash2 className="w-3 h-3" /></Button>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="flex-1 grid grid-cols-3 gap-1">
                          <div>
                            <Label className="text-[10px] text-muted-foreground">IP từ</Label>
                            <Input type="number" placeholder="0" value={tier.minFYP || ''} onChange={(e) => updateBonusTier(tier.id, 'minFYP', parseFloat(e.target.value) || 0)} className="h-7 text-xs border-amber-200" />
                          </div>
                          <div>
                            <Label className="text-[10px] text-muted-foreground">IP đến</Label>
                            <Input type="number" placeholder="∞" value={tier.maxFYP ?? ''} onChange={(e) => updateBonusTier(tier.id, 'maxFYP', e.target.value ? parseFloat(e.target.value) : null)} className="h-7 text-xs border-amber-200" />
                          </div>
                          <div>
                            <Label className="text-[10px] text-muted-foreground">
                              {tier.bonusType === 'money' ? 'Thưởng (VNĐ)' : 'Quà tặng'}
                            </Label>
                            {tier.bonusType === 'money' ? (
                              <Input type="number" placeholder="0" value={tier.bonusAmount || ''} onChange={(e) => updateBonusTier(tier.id, 'bonusAmount', parseFloat(e.target.value) || 0)} className="h-7 text-xs border-amber-200" />
                            ) : (
                              <Input type="text" placeholder="VD: 1 iPhone 15" value={tier.bonusText} onChange={(e) => updateBonusTier(tier.id, 'bonusText', e.target.value)} className="h-7 text-xs border-pink-200" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="rounded-lg bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-200 p-3">
                  <p className="text-xs font-medium text-amber-800 mb-2">Tham chiếu mức thưởng:</p>
                  <div className="space-y-1">
                    {sortedTiers.map((tier, i) => (
                      <div key={tier.id} className="flex justify-between text-xs text-amber-700">
                        <span className="flex items-center gap-1">
                          {tier.bonusType === 'gift' ? <Gift className="w-3 h-3" /> : <Sparkles className="w-3 h-3" />}
                          Mức {i + 1}: {formatCurrency(tier.minFYP)}{tier.maxFYP ? ` - ${formatCurrency(tier.maxFYP)}` : ' ↑'}
                        </span>
                        <span className="font-medium truncate ml-2 max-w-[140px]" title={formatBonus(tier)}>{formatBonus(tier)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Live Preview Poster */}
            <div className="mt-5">
              <ContestPoster
                contestTitle={contestTitle}
                startDate={startDate}
                endDate={endDate}
                conditionType={conditionType}
                targetType={targetType}
                sortedTiers={sortedTiers}
                filteredContracts={filteredContracts}
                groupedData={groupedData}
                totalFYP={displayTotalFYP}
                totalBonus={totalBonusDisplay}
                achievedCount={achievedCount}
                notAchievedCount={notAchievedCount}
                formatCurrency={formatCurrency}
                formatNumber={formatNumber}
                formatDate={formatDate}
                isPreview
              />
            </div>

            <div className="mt-4 flex gap-2">
              <Button onClick={handleSearch} className="bg-emerald-600 hover:bg-emerald-700">
                <Search className="w-4 h-4 mr-2" /> Tính kết quả thi đua
              </Button>
              <Button variant="outline" onClick={() => { setStartDate(''); setEndDate(''); setIssueDate(''); setFilteredContracts([]); setSelectedContestId(''); }}>
                <X className="w-4 h-4 mr-2" /> Xóa
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results Section */}
        {filteredContracts.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={handleCopyText} className="border-teal-300 text-teal-700 hover:bg-teal-50">
                <Copy className="w-4 h-4 mr-1" /> Copy chia sẻ
              </Button>
              <Button variant="outline" size="sm" onClick={handlePrint} className="border-emerald-300 text-emerald-700 hover:bg-emerald-50">
                <Printer className="w-4 h-4 mr-1" /> In / Lưu PDF
              </Button>
              <Button variant="outline" size="sm" onClick={handleExport}>
                <Download className="w-4 h-4 mr-1" /> Xuất CSV
              </Button>
            </div>

            <div ref={printRef}>
              <div className="hidden print:block mb-4">
                <div className="header">
                  <h1>{contestTitle}</h1>
                  <div className="subtitle">Từ {startDate ? formatDate(startDate) : '...'} đến {endDate ? formatDate(endDate) : '...'} | Đối tượng: {targetType === 'tvv' ? 'TVV' : 'Nhóm'}</div>
                </div>
              </div>

              <Card className="border-2 border-emerald-300 shadow-lg overflow-hidden">
                <ContestPoster
                  contestTitle={contestTitle}
                  startDate={startDate}
                  endDate={endDate}
                  conditionType={conditionType}
                  targetType={targetType}
                  sortedTiers={sortedTiers}
                  filteredContracts={filteredContracts}
                  groupedData={groupedData}
                  totalFYP={displayTotalFYP}
                  totalBonus={totalBonusDisplay}
                  achievedCount={achievedCount}
                  notAchievedCount={notAchievedCount}
                  formatCurrency={formatCurrency}
                  formatNumber={formatNumber}
                  formatDate={formatDate}
                />

                {/* Total FYP mode info */}
                {conditionType === 'total_fyp' && matchedTotalTier && (
                  <div className="mx-4 mt-3 rounded-lg bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 p-3">
                    <div className="flex items-center gap-3">
                      <TrendingUp className="w-5 h-5 text-amber-600 flex-shrink-0" />
                      <div className="flex-1">
                        <p className="text-sm font-bold text-amber-800">Tổng IP: {formatCurrency(totalFYPValue)}</p>
                        <p className="text-xs text-amber-700">Mức áp dụng: {formatCurrency(matchedTotalTier.minFYP)}{matchedTotalTier.maxFYP ? ` - ${formatCurrency(matchedTotalTier.maxFYP)}` : ' trở lên'}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-amber-600">Thưởng nhận</p>
                        <p className="text-xl font-extrabold text-amber-700">{formatBonus(matchedTotalTier)}</p>
                      </div>
                      {totalRemaining !== null && (
                        <div className="text-right border-l pl-3">
                          <p className="text-xs text-orange-600">Cần thêm</p>
                          <p className="text-lg font-bold text-orange-700">{formatCurrency(totalRemaining)}</p>
                          <p className="text-[10px] text-orange-500">để đạt mức tiếp</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Results Table */}
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-gray-800 hover:bg-gray-800">
                        <TableHead className="text-center text-gray-200 whitespace-normal w-[45px]">STT</TableHead>
                        <TableHead className="text-gray-200 whitespace-normal min-w-[90px]">Nhóm</TableHead>
                        {targetType === 'nhom' ? (
                          <>
                            <TableHead className="text-gray-200 whitespace-normal min-w-[150px]">Trưởng nhóm</TableHead>
                            <TableHead className="text-gray-200 whitespace-normal text-center min-w-[70px]">Số HĐ</TableHead>
                          </>
                        ) : (
                          <>
                            <TableHead className="text-gray-200 whitespace-normal min-w-[85px]">Mã số</TableHead>
                            <TableHead className="text-gray-200 whitespace-normal min-w-[150px]">Họ tên</TableHead>
                            <TableHead className="text-gray-200 whitespace-normal text-center min-w-[95px]">Ngày hiệu lực</TableHead>
                          </>
                        )}
                        <TableHead className="text-gray-200 whitespace-normal text-right min-w-[110px]">IP / Tổng</TableHead>
                        <TableHead className="text-gray-200 whitespace-normal text-right min-w-[110px]">Thưởng</TableHead>
                        <TableHead className="text-gray-200 whitespace-normal min-w-[130px]">Ghi chú</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {targetType === 'nhom' ? (
                        // GROUP MODE
                        [...groupedData]
                          .map((g) => {
                            const { tier } = calculateBonus(g.totalFYP);
                            const remaining = getRemainingToNextTier(g.totalFYP);
                            return { group: g, tier, remaining };
                          })
                          .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.group.totalFYP - a.group.totalFYP)
                          .map(({ group, tier, remaining }, idx) => {
                            const achieved = tier !== null;
                            return (
                              <TableRow key={group.maNhom} className={`${achieved ? 'bg-white' : 'bg-red-50/30'} hover:bg-emerald-50/60`}>
                                <TableCell className="text-center font-semibold text-gray-500 whitespace-nowrap">{idx + 1}</TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <span className="font-mono text-xs text-emerald-700 font-semibold">{group.maNhom}</span>
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <span className="font-medium text-sm">{group.leaderName || group.maNhom}</span>
                                  {group.leaderCode && <span className="text-xs text-gray-400 ml-1">({group.leaderCode})</span>}
                                </TableCell>
                                <TableCell className="text-center whitespace-nowrap">
                                  <Badge variant="secondary" className="text-xs">{group.contractCount} HĐ</Badge>
                                </TableCell>
                                <TableCell className="text-right whitespace-nowrap">
                                  <span className="font-bold text-emerald-700">{formatNumber(group.totalFYP)}</span>
                                </TableCell>
                                <TableCell className="text-right whitespace-nowrap">
                                  {achieved && tier ? (
                                    <span className={`font-bold ${tier.bonusType === 'gift' ? 'text-pink-600' : 'text-emerald-600'}`}>
                                      {formatBonus(tier)}
                                    </span>
                                  ) : (
                                    <span className="text-gray-300">—</span>
                                  )}
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                  {achieved ? (
                                    <span></span>
                                  ) : remaining !== null ? (
                                    <span className="text-[11px] italic text-gray-400">Còn thiếu {formatNumber(remaining)}</span>
                                  ) : (
                                    <span className="text-[11px] italic text-gray-400">Chưa đạt mức</span>
                                  )}
                                </TableCell>
                              </TableRow>
                            );
                          })
                      ) : (
                        // TVV MODE
                        [...filteredContracts]
                          .map((c) => {
                            const { tier } = conditionType === 'per_contract' ? calculateBonus(c.fyp) : { tier: null as BonusTier | null };
                            const remaining = conditionType === 'per_contract' ? getRemainingToNextTier(c.fyp) : null;
                            return { contract: c, tier, remaining };
                          })
                          .sort((a, b) => (b.tier?.bonusAmount || 0) - (a.tier?.bonusAmount || 0) || b.contract.fyp - a.contract.fyp)
                          .map(({ contract, tier, remaining }, idx) => {
                            const achieved = tier !== null;
                            return (
                              <TableRow key={contract.id} className={`${achieved ? 'bg-white' : 'bg-red-50/30'} hover:bg-emerald-50/60`}>
                                <TableCell className="text-center font-semibold text-gray-500 whitespace-nowrap">{idx + 1}</TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <span className="font-mono text-xs text-emerald-700 font-semibold">{contract.maNhom}</span>
                                </TableCell>
                                <TableCell className="font-mono text-xs whitespace-nowrap">{contract.agentCode}</TableCell>
                                <TableCell className="whitespace-nowrap">
                                  <span className="font-medium text-sm">{contract.agentName}</span>
                                </TableCell>
                                <TableCell className="text-center whitespace-nowrap">
                                  <span className="text-xs text-gray-600">{formatDate(contract.effectiveDate)}</span>
                                </TableCell>
                                <TableCell className="text-right whitespace-nowrap">
                                  <span className="font-bold text-emerald-700">{formatNumber(contract.fyp)}</span>
                                </TableCell>
                                <TableCell className="text-right whitespace-nowrap">
                                  {achieved && tier ? (
                                    <span className={`font-bold ${tier.bonusType === 'gift' ? 'text-pink-600' : 'text-emerald-600'}`}>
                                      {formatBonus(tier)}
                                    </span>
                                  ) : (
                                    <span className="text-gray-300">—</span>
                                  )}
                                </TableCell>
                                <TableCell className="whitespace-nowrap">
                                  {achieved ? (
                                    <span></span>
                                  ) : remaining !== null ? (
                                    <span className="text-[11px] italic text-gray-400">Còn thiếu {formatNumber(remaining)}</span>
                                  ) : (
                                    <span className="text-[11px] italic text-gray-400">Chưa đạt mức</span>
                                  )}
                                </TableCell>
                              </TableRow>
                            );
                          })
                      )}
                    </TableBody>
                  </Table>
                </div>

                {/* Total Footer */}
                <div className="bg-gray-900 text-white px-6 py-4">
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase">{targetType === 'nhom' ? 'Tổng nhóm' : 'Tổng HĐ'}</p>
                      <p className="text-lg font-bold">{targetType === 'nhom' ? groupedData.length : filteredContracts.length}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase">Tổng IP</p>
                      <p className="text-lg font-bold">{formatCurrency(displayTotalFYP)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase">Tổng Thưởng</p>
                      <p className="text-2xl font-extrabold text-amber-400">{formatCurrency(totalBonusDisplay)}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase">Đạt / Chưa đạt</p>
                      <p className="text-lg font-bold">
                        <span className="text-emerald-400">{achievedCount}</span>
                        <span className="text-gray-500 mx-1">/</span>
                        <span className="text-red-400">{notAchievedCount}</span>
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-400 uppercase">Tỷ lệ thưởng / IP</p>
                      <p className="text-lg font-bold text-emerald-400">{displayTotalFYP > 0 ? ((totalBonusDisplay / displayTotalFYP) * 100).toFixed(2) : '0.00'}%</p>
                    </div>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        )}

        {/* Empty State */}
        {filteredContracts.length === 0 && (
          <Card className="border-gray-200 shadow-sm">
            <CardContent className="py-16 text-center text-gray-400">
              <Trophy className="w-16 h-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg font-medium text-gray-500">Thiết lập chương trình thi đua</p>
              <p className="text-sm">Nhập ngày, cấu hình mức thưởng và nhấn &ldquo;Tính kết quả thi đua&rdquo;</p>
            </CardContent>
          </Card>
        )}

        {/* All Contracts */}
        <Card className="border-gray-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-gray-600" />
                <CardTitle className="text-lg">Dữ liệu nguồn</CardTitle>
                <Badge variant="secondary">{contracts.length} HĐ</Badge>
                <span className="text-xs text-gray-400">| Tổng: {formatCurrency(contracts.reduce((s, c) => s + c.fyp, 0))} IP</span>
              </div>
              <Button variant="ghost" size="sm" onClick={fetchContracts}>
                <RefreshCw className="w-4 h-4 mr-1" /> Làm mới
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {contracts.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Database className="w-10 h-10 mx-auto mb-2 opacity-30" />
                <p className="font-medium">Chưa có dữ liệu</p>
                <p className="text-sm">Nhấn &ldquo;Nhập Google Sheets&rdquo; để tải dữ liệu</p>
              </div>
            ) : (
              <div className="rounded-lg border overflow-x-auto max-h-64 overflow-y-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-50 sticky top-0">
                      <TableHead className="w-[40px] text-center">STT</TableHead>
                      <TableHead>Mã nhóm</TableHead>
                      <TableHead>Mã số</TableHead>
                      <TableHead>Họ tên TVV</TableHead>
                      <TableHead>Chức vụ</TableHead>
                      <TableHead>Ngày hiệu lực</TableHead>
                      <TableHead>IP</TableHead>
                      <TableHead>AFYP</TableHead>
                      <TableHead className="w-[40px]"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contracts.map((c, idx) => (
                      <TableRow key={c.id} className="hover:bg-gray-50">
                        <TableCell className="text-center text-gray-500">{idx + 1}</TableCell>
                        <TableCell className="font-mono text-xs text-emerald-700 whitespace-nowrap">{c.maNhom}</TableCell>
                        <TableCell className="font-mono text-xs whitespace-nowrap">{c.agentCode}</TableCell>
                        <TableCell className="text-sm whitespace-nowrap">{c.agentName}</TableCell>
                        <TableCell className="text-xs whitespace-nowrap">{c.position}</TableCell>
                        <TableCell className="text-xs text-gray-600 whitespace-nowrap">{formatDate(c.effectiveDate)}</TableCell>
                        <TableCell className="font-semibold text-emerald-700 text-sm whitespace-nowrap">{formatNumber(c.fyp)}</TableCell>
                        <TableCell className="text-sm text-sky-700 whitespace-nowrap">{formatNumber(c.afyp)}</TableCell>
                        <TableCell><Button variant="ghost" size="sm" onClick={() => handleDeleteContract(c.id)} className="h-7 w-7 p-0 text-red-400 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></Button></TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
